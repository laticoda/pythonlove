pipenv --python 3.7.3 install pyglet arcade

pipenv shell

python pythonlove.py






sometimes you must launch again the game to make your joystick warm enought to work...
