#! /usr/bin/env python3
# -*- coding: utf-8 -*-

import random
import arcade
import os

""" theory for inheritence : super() and signatures

class Computer():
    def __init__(self, computer, ram, ssd):
        self.computer = computer
        self.ram = ram
        self.ssd = ssd

class Laptop(Computer):
    def __init__(self, computer, ram, ssd, model):
        super().__init__(computer, ram, ssd)
        self.model = model

"""



class MyCustomNamedSprite(arcade.Sprite):

    def __init__(self,relative_path_to_png, SPRITE_SCALING, sprite_pseudo):
        super().__init__(relative_path_to_png, SPRITE_SCALING)
        self.sprite_pseudo = sprite_pseudo # type str !!!


class BouncingSprite(MyCustomNamedSprite):
    # mangustas bullets class is inherited for bounce managing

    def __init__(self,relative_path_to_png, SPRITE_SCALING, sprite_pseudo, bounce_limit):
        super().__init__(relative_path_to_png, SPRITE_SCALING, sprite_pseudo)
        self.bounce_limit = bounce_limit

    def check_bounce_or_kill(self):
        self.bounce_limit -= 1
        if not self.bounce_limit >0:
            self.kill()







class MyBirdySprite(MyCustomNamedSprite):

    def __init__(self,relative_path_to_png, SPRITE_SCALING, sprite_pseudo, circle_angle, circle_radius, circle_speed, circle_center_x, circle_center_y):
        super().__init__(relative_path_to_png, SPRITE_SCALING, sprite_pseudo)
        self.circle_angle = circle_angle
        self.circle_radius = circle_radius
        self.circle_speed = circle_speed
        self.circle_center_x = circle_center_x
        self.circle_center_y = circle_center_y




class Explosion(arcade.Sprite):
    

    def __init__(self, texture_list,x,y):
        
        super().__init__()

        self.center_x = x
        self.center_y = y
        
        self.current_texture = 0      
        self.textures = texture_list  
        self.set_texture(self.current_texture)

    def update(self):

        
        self.current_texture += 1
        if self.current_texture < len(self.textures):
            self.set_texture(self.current_texture)
        else:
            self.kill()