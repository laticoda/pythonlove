#! /usr/bin/env python3
# -*- coding: utf-8 -*-



import random
import arcade
import os

from custom_named_sprite import MyCustomNamedSprite, MyBirdySprite, BouncingSprite, Explosion

import math



TILE_SCALING = SPRITE_SCALING = 1

SCREEN_WIDTH = 1280
SCREEN_HEIGHT = 704
SCREEN_TITLE = "Laticoda's Python Love : Python Game Jam 2019! on itch.io"

# How many pixels to keep as a minimum margin between the character
# and the edge of the screen.
VIEWPORT_MARGIN = SCREEN_HEIGHT // 2 

MOVEMENT_SPEED = 7

GRID_PIXEL_SIZE = 32

ROOM_SIZE_IN_TILES = 40*40

MAP_IN_TILES = 2*2*ROOM_SIZE_IN_TILES
MAP_IN_PIXEL = MAP_IN_TILES*GRID_PIXEL_SIZE

MOVEMENT_MULTIPLIER = 5
DEAD_ZONE = 0.05

PLAYER_HEALT_BIRTH = 150
LIVES_START = 2


BULLET_RACCOON_SPEED = 5
BULLET_RACCOON_DAMAGE = PLAYER_HEALT_BIRTH // 5

BULLET_MANGUSTA_SPEED = 6
BULLET_MANGUSTA_DAMAGE = PLAYER_HEALT_BIRTH // 3
BOUNCE_LIMIT_BULLET_MANGUSTA = 6

BIRTH_POSITION_X = 64
BIRTH_POSITION_Y = 270 


class MyGame(arcade.Window):
    """ Main application class. """

    def __init__(self, width, height, title):
        """
        Initializer
        """
        super().__init__(width, height, title)

        # Set the working directory (where we expect to find files) to the same
        # directory this .py file is in. You can leave this out of your own
        # code, but it is needed to easily run the examples using "python -m"
        # as mentioned at the top of this program.
        file_path = os.path.dirname(os.path.abspath(__file__))
        os.chdir(file_path)

        self.frame_count = 0

        # Sprite lists
        self.player_list = None
        self.coin_list = None

        # Set up the player
        self.player_sprite = None
        self.wall_list = None
        self.physics_engine = None
        self.view_bottom = 0
        self.view_left = 0

        self.gameover = None

        self.lives = 0

        self.health = 0
        self.is_living = None
        self.showing_explosion = None

        self.enemy_list = None
        self.bullet_list = None

        self.explosion_images = None
        self.explosion_list = None


        self.score = 0
        

        joysticks = arcade.get_joysticks()
        if joysticks:
            self.joystick = joysticks[0]
            self.joystick.open()
            self.joystick.on_joybutton_press = self.on_joybutton_press
            self.joystick.on_joybutton_release = self.on_joybutton_release
            self.joystick.on_joyhat_motion = self.on_joyhat_motion
        else:
            print("There are no Joysticks")
            self.joystick = None

    def on_joybutton_press(self, joystick, button):
        print("Button {} down".format(button))

    def on_joybutton_release(self, joystick, button):
        print("Button {} up".format(button))

    def on_joyhat_motion(self, joystick, hat_x, hat_y):
        print("Hat ({}, {})".format(hat_x, hat_y))

    def setup(self):
        """ Set up the game and initialize the variables. """

        self.enemy_list = arcade.SpriteList()
        self.bullet_list = arcade.SpriteList()

        enemy_raccoon = MyCustomNamedSprite("images/rac_64_xP.png", 1, "enemy_raccoon")
        enemy_raccoon.center_x = 1000
        enemy_raccoon.center_y = SCREEN_HEIGHT //2
        enemy_raccoon.angle = 0
        self.enemy_list.append(enemy_raccoon)

        enemy_raccoon = MyCustomNamedSprite("images/rac_64_xP.png", 1, "enemy_raccoon")
        enemy_raccoon.center_x = 120
        enemy_raccoon.center_y = 400 
        enemy_raccoon.angle = 0
        self.enemy_list.append(enemy_raccoon)

        enemy_raccoon = MyCustomNamedSprite("images/rac_64_xP.png", 1, "enemy_raccoon")
        enemy_raccoon.center_x = SCREEN_WIDTH - 100
        enemy_raccoon.center_y = 64 
        enemy_raccoon.angle = 0
        self.enemy_list.append(enemy_raccoon)


        enemy_wolf = MyCustomNamedSprite("images/wolf_96_xP.png", 1, "enemy_wolf")
        enemy_wolf.center_x = 1000
        enemy_wolf.center_y = 600 +SCREEN_HEIGHT 
        enemy_wolf.angle = 0
        self.enemy_list.append(enemy_wolf)

        enemy_wolf = MyCustomNamedSprite("images/wolf_96_xP.png", 1, "enemy_wolf")
        enemy_wolf.center_x = 1000
        enemy_wolf.center_y = 600 
        enemy_wolf.angle = 0
        self.enemy_list.append(enemy_wolf)

        enemy_eagle = MyBirdySprite("images/eagle_std_128_x.png", 1, "enemy_eagle",random.random() * 2 * math.pi,random.randrange(10, 200),0.003,random.randrange(SCREEN_WIDTH),random.randrange(SCREEN_HEIGHT))
        enemy_eagle.center_x = 600
        enemy_eagle.center_y = 100 + SCREEN_HEIGHT 
        enemy_eagle.angle = 0
        
        self.enemy_list.append(enemy_eagle)

        enemy_eagle = MyBirdySprite("images/eagle_std_128_x.png", 1, "enemy_eagle",random.random() * 2 * math.pi,random.randrange(100, 400),0.009,random.randrange(SCREEN_WIDTH),random.randrange(SCREEN_HEIGHT))
        enemy_eagle.center_x = 600
        enemy_eagle.center_y = 100 
        enemy_eagle.angle = 0
        
        self.enemy_list.append(enemy_eagle)

        enemy_mangusta = MyCustomNamedSprite("images/mangusta_64_x.png", 1, "enemy_mangusta")
        enemy_mangusta.center_x = 640
        enemy_mangusta.center_y = - 125 + SCREEN_HEIGHT 
        enemy_mangusta.angle = 0
        self.enemy_list.append(enemy_mangusta)

        enemy_mangusta = MyCustomNamedSprite("images/mangusta_64_x.png", 1, "enemy_mangusta")
        enemy_mangusta.center_x = 640
        enemy_mangusta.center_y = 125 
        enemy_mangusta.angle = 0
        self.enemy_list.append(enemy_mangusta)

        enemy_mangusta = MyCustomNamedSprite("images/mangusta_64_x.png", 1, "enemy_mangusta")
        enemy_mangusta.center_x =  100 + SCREEN_WIDTH // 2
        enemy_mangusta.center_y =  150 + SCREEN_HEIGHT // 2
        enemy_mangusta.angle = 0
        self.enemy_list.append(enemy_mangusta)

        # Sprite lists
        self.player_list = arcade.SpriteList()
        self.wall_list = arcade.SpriteList()

        # Set up the player
        
        self.player_sprite = arcade.Sprite("images/python_32_x.png", 1)

        self.gameover = False

        self.score = 0

        self.lives = LIVES_START

        self.health = PLAYER_HEALT_BIRTH
        self.is_living = True
        self.showing_explosion = False

        self.explosion_images = []

        for i in range(32):  
        
                        
            texture_name = f"images/explosion/explosion{i:04d}.png"
            self.explosion_images.append(arcade.load_texture(texture_name))

        self.explosion_list = arcade.SpriteList()

        

        self.player_sprite.center_x = BIRTH_POSITION_X
        self.player_sprite.center_y = BIRTH_POSITION_Y
        self.player_list.append(self.player_sprite)

        #-------------------------------------------------------------

        platforms_layer_name = "Platforms"

        map_name = f"forty.tmx"


        my_map = arcade.tilemap.read_tmx(map_name)

        self.end_of_map = my_map.map_size.width * GRID_PIXEL_SIZE

        # -- Platforms
        self.wall_list = arcade.tilemap.process_layer(
            my_map, platforms_layer_name, TILE_SCALING
        )

        

        self.physics_engine = arcade.PhysicsEngineSimple(self.player_sprite, self.wall_list)

        # Set the background color
        arcade.set_background_color(arcade.color.AMAZON)

        # Set the viewport boundaries
        # These numbers set where we have 'scrolled' to.
        self.view_left = 0
        self.view_bottom = 0



    def on_draw(self):
        """
        Render the screen.
        """

        # This command has to happen before we start drawing
        arcade.start_render()

        # Draw all the sprites.
        self.wall_list.draw()

        self.enemy_list.draw()
        self.bullet_list.draw()

        self.player_list.draw()

        self.draw_player_lifebar()

        self.explosion_list.draw()

        info_score = "score:  " + str(self.score)
        arcade.draw_text(info_score, 15, SCREEN_HEIGHT-30, arcade.color.YELLOW, 18 )

        info_lives = "lives:  " + str(self.lives)
        arcade.draw_text(info_lives, 700, SCREEN_HEIGHT-30, arcade.color.PINK, 14 )

        


    def draw_player_lifebar(self):
        x = self.player_sprite.center_x
        y = self.player_sprite.center_y

        
        arcade.draw_rectangle_filled(x, y - 25, 24, 4, (255, 0, 0))

        
        if not self.health <= 0:
            arcade.draw_rectangle_filled(x - math.ceil((24 - (self.health / 4.16)) / 2), y - 25, math.ceil(self.health / 4.16), 4, (0, 255, 0))



    def on_key_press(self, key, modifiers):
        """Called whenever a key is pressed. """

        if key == arcade.key.UP:
            self.player_sprite.change_y = MOVEMENT_SPEED
        elif key == arcade.key.DOWN:
            self.player_sprite.change_y = -MOVEMENT_SPEED
        elif key == arcade.key.LEFT:
            self.player_sprite.change_x = -MOVEMENT_SPEED
        elif key == arcade.key.RIGHT:
            self.player_sprite.change_x = MOVEMENT_SPEED

    def on_key_release(self, key, modifiers):
        """Called when the user releases a key. """

        if key == arcade.key.UP or key == arcade.key.DOWN:
            self.player_sprite.change_y = 0
        elif key == arcade.key.LEFT or key == arcade.key.RIGHT:
            self.player_sprite.change_x = 0









    def update(self, delta_time):
        """ Movement and game logic """

        # Call update on all sprites (The sprites don't do much in this
        # example though.)
        self.physics_engine.update()

        # --- Manage Scrolling ---

        # Track if we need to change the viewport

        if self.joystick:
            self.player_sprite.change_x = self.joystick.x * MOVEMENT_MULTIPLIER
            # Set a "dead zone" to prevent drive from a centered joystick
            if abs(self.player_sprite.change_x) < DEAD_ZONE:
                self.player_sprite.change_x = 0

            self.player_sprite.change_y = -self.joystick.y * MOVEMENT_MULTIPLIER
            # Set a "dead zone" to prevent drive from a centered joystick
            if abs(self.player_sprite.change_y) < DEAD_ZONE:
                self.player_sprite.change_y = 0

        """ Move everything """
        #self.player.move()



        changed = False

        # Scroll left
        left_bndry = self.view_left + VIEWPORT_MARGIN
        if self.player_sprite.left < left_bndry:
            self.view_left -= left_bndry - self.player_sprite.left
            changed = True

        # Scroll right
        right_bndry = self.view_left + SCREEN_WIDTH - VIEWPORT_MARGIN
        if self.player_sprite.right > right_bndry:
            self.view_left += self.player_sprite.right - right_bndry
            changed = True

        # Scroll up
        top_bndry = self.view_bottom + SCREEN_HEIGHT - VIEWPORT_MARGIN
        if self.player_sprite.top > top_bndry:
            self.view_bottom += self.player_sprite.top - top_bndry
            changed = True

        # Scroll down
        bottom_bndry = self.view_bottom + VIEWPORT_MARGIN
        if self.player_sprite.bottom < bottom_bndry:
            self.view_bottom -= bottom_bndry - self.player_sprite.bottom
            changed = True

        if changed:
            arcade.set_viewport(self.view_left,
                                SCREEN_WIDTH + self.view_left,
                                self.view_bottom,
                                SCREEN_HEIGHT + self.view_bottom)



        self.frame_count += 1

        # Loop through each enemy that we have
        #for enemy in self.enemy_list if enemy.sprite_pseudo == "enemy_raccoon":
        for enemy in self.enemy_list:

            if enemy.sprite_pseudo == "enemy_raccoon":

                # First, calculate the angle to the player. We could do this
                # only when the bullet fires, but in this case we will rotate
                # the enemy to face the player each frame, so we'll do this
                # each frame.

                # Position the start at the enemy's current location
                start_x = enemy.center_x
                start_y = enemy.center_y

                # Get the destination location for the bullet
                dest_x = self.player_sprite.center_x
                dest_y = self.player_sprite.center_y

                # Do math to calculate how to get the bullet to the destination.
                # Calculation the angle in radians between the start points
                # and end points. This is the angle the bullet will travel.
                x_diff = dest_x - start_x
                y_diff = dest_y - start_y
                angle = math.atan2(y_diff, x_diff)

                # Set the enemy to face the player.
                enemy.angle = math.degrees(angle)-90

                # Shoot every 60 frames change of shooting each frame
                if self.frame_count % 60 == 0:
                    bullet_raccoon = MyCustomNamedSprite("images/burden.png",1,"bullet_raccoon")

                    

                    bullet_raccoon.center_x = start_x
                    bullet_raccoon.center_y = start_y

                    # Angle the bullet sprite
                    bullet_raccoon.angle = math.degrees(angle)

                    # Taking into account the angle, calculate our change_x
                    # and change_y. Velocity is how fast the bullet travels.
                    bullet_raccoon.change_x = math.cos(angle) * BULLET_RACCOON_SPEED
                    bullet_raccoon.change_y = math.sin(angle) * BULLET_RACCOON_SPEED

                    self.bullet_list.append(bullet_raccoon)

            



            if enemy.sprite_pseudo == "enemy_mangusta":

                # First, calculate the angle to the player. We could do this
                # only when the bullet fires, but in this case we will rotate
                # the enemy to face the player each frame, so we'll do this
                # each frame.

                # Position the start at the enemy's current location
                start_x = enemy.center_x
                start_y = enemy.center_y

                # Get the destination location for the bullet
                dest_x = self.player_sprite.center_x
                dest_y = self.player_sprite.center_y

                # Do math to calculate how to get the bullet to the destination.
                # Calculation the angle in radians between the start points
                # and end points. This is the angle the bullet will travel.
                x_diff = dest_x - start_x
                y_diff = dest_y - start_y
                angle = math.atan2(y_diff, x_diff)

                # Set the enemy to face the player.
                enemy.angle = math.degrees(angle)-90

                # Shoot every 60 frames change of shooting each frame
                if self.frame_count % 240 == 0:
                    bullet_mangusta = BouncingSprite("images/redrock_32_x.png",1,"bullet_mangusta", BOUNCE_LIMIT_BULLET_MANGUSTA)
                    bullet_mangusta.center_x = start_x
                    bullet_mangusta.center_y = start_y

                    # Angle the bullet sprite
                    bullet_mangusta.angle = math.degrees(angle)

                    # Taking into account the angle, calculate our change_x
                    # and change_y. Velocity is how fast the bullet travels.
                    bullet_mangusta.change_x = math.cos(angle) * BULLET_MANGUSTA_SPEED
                    bullet_mangusta.change_y = math.sin(angle) * BULLET_MANGUSTA_SPEED

                    self.bullet_list.append(bullet_mangusta)

            

            if enemy.sprite_pseudo == "enemy_wolf":
                i = random.randint(0, 150) #print("WOLF")
                if i> 145:
                    enemy.center_x += 0.3*random.randint(- i, i)
                    enemy.center_y += 0.3*random.randint(- i, i)


            if enemy.sprite_pseudo == "enemy_eagle":
                enemy.center_x = enemy.circle_radius * math.sin(enemy.circle_angle) \
            + enemy.circle_center_x
                enemy.center_y = enemy.circle_radius * math.cos(enemy.circle_angle) \
                + enemy.circle_center_y

                # Increase the angle in prep for the next round.
                enemy.circle_angle += enemy.circle_speed


        for bullet in self.bullet_list:

            if arcade.check_for_collision(bullet, self.player_sprite):
                if bullet.sprite_pseudo == "bullet_mangusta":
                    self.health -= BULLET_MANGUSTA_DAMAGE
                    bullet.kill()
                if bullet.sprite_pseudo == "bullet_raccoon":
                    self.health -= BULLET_RACCOON_DAMAGE
                    bullet.kill()


                
                #arcade.play_sound(self.sound_list[random.randint(7, 9)])
                
            

            if not bullet.sprite_pseudo == "bullet_mangusta":
                #if bullet.top < 0:
                if bullet.top < 0 or bullet.right <0 or bullet.bottom > SCREEN_HEIGHT or bullet.left > SCREEN_WIDTH:
                    bullet.kill()


            if bullet.sprite_pseudo == "bullet_mangusta":

                
                


                bullet.center_x += bullet.change_x
                walls_hit = arcade.check_for_collision_with_list(bullet, self.wall_list)
                for wall in walls_hit:
                    if bullet.change_x > 0:
                        bullet.right = wall.left
                        #bullet.check_bounce_or_kill()
                    elif bullet.change_x < 0:
                        bullet.left = wall.right
                        #bullet.check_bounce_or_kill()
                if len(walls_hit) > 0:
                    bullet.change_x *= -1
                    bullet.check_bounce_or_kill()

                bullet.center_y += bullet.change_y
                walls_hit = arcade.check_for_collision_with_list(bullet, self.wall_list)
                for wall in walls_hit:
                    if bullet.change_y > 0:
                        bullet.top = wall.bottom
                        #bullet.check_bounce_or_kill()
                    elif bullet.change_y < 0:
                        bullet.bottom = wall.top
                        #bullet.check_bounce_or_kill()
                if len(walls_hit) > 0:
                    bullet.change_y *= -1




        self.bullet_list.update()

        if self.health < 0 :
            #if self.is_living is True:
            #    self.is_living = False 

            if self.showing_explosion is False:
                e = Explosion(self.explosion_images,self.player_sprite.center_x,self.player_sprite.center_y)
                self.explosion_list.append(e)
                self.player_sprite.kill()
                e.update()
                self.showing_explosion = True

            if self.showing_explosion is True:
                self.player_sprite.kill()

                try:
                    self.explosion_list[0].update()
                except IndexError as e:
                    print(e)
                    self.explosion_list = arcade.SpriteList()
                    self.showing_explosion = False
                    #self.is_living is True
                    self.lives -= 1
                    if not self.lives <0:
                        self.health = PLAYER_HEALT_BIRTH
                        self.player_list.append(self.player_sprite)
                        self.player_sprite.update()
                    else:
                        print("\n\n\n NO TIME TO FINISH IT, thank you to arcade library coder and students")
                        print("\n thanks for assets i picked up everywhere")
                        print("\n this is for education prpose, NO COMMERCIAL (lol)")
                        
                        raise GAMEOVER


                


                


def main():
    """ Main method """
    window = MyGame(SCREEN_WIDTH, SCREEN_HEIGHT, SCREEN_TITLE)
    window.setup()
    arcade.run()


if __name__ == "__main__":
    main()
